# Documentação do Processo de Construção do Demonstrativo de Fluxo de Caixa

## Cadastro de Campos Adicionais

### Tabela: TGFNAT (Natureza)

- Campo: **AGRUDFC**
    - Descrição: Agrupador DFC SQA
    - Tipo de dados: Número Inteiro
    - Apresentação: Lista de Opções
    - Função do Campo: Campo responsável por classificar e agrupar os grupos do demonstrativo

| Valor | Opção                             | Ordem |
|-------|-----------------------------------|-------|
| 100   | ( = ) Atividades Operacionais     | 1     |
| 200   | ( = ) Atividades de Investimento  | 2     |
| 300   | ( = ) Atividades de Financiamento | 3     |


- Campo: **AGRUDFC_2**
    - Descrição: Agrupador DFC Nivel 2 SQA
    - Tipo de dados: Número Inteiro
    - Apresentação: Lista de Opções
    - Função do Campo: Campo responsável por classificar e agrupar os grupos do demonstrativo de nível 2

| Valor | Opção                              | Ordem |
|-------|------------------------------------|-------|
| 101   | ( + ) Recebimento Vendas           | 1     |
| 102   | ( - ) Pagamento Fornecedores       | 2     |
| 103   | ( - ) Pagamento Folha              | 3     |
| 104   | ( - ) Pagamento Desp. Operacionais | 4     |
| 105   | ( - ) Pagamento Tributos           | 5     |
| 106   | ( +/- ) Juros/Taxas e Rendim. Op.  | 6     |
| 107   | ( +/- ) Adiantamentos              | 7     |
| 201   | ( - ) Compra Imobilizado           | 8     |
| 202   | ( + ) Venda Imobilizado            | 9     |
| 203   | ( + )Juros e rendimentos recebidos | 10    |
| 301   | ( - ) Distribuição Lucro           | 11    |
| 302   | ( + ) Aporte de Capital            | 12    |
| 303   | ( - ) Pagamento endividamento      | 13    |



- Campo: **ORDEMDFC**
    - Descrição do Campo: Ordenador DFC SQA
    - Tipo de dados: Número Inteiro
    - Apresentação: Padrão
    - Função do Campo: Campo responsável por trazer o ordenamento dos demonstrativos se necessário sua utilização *(por hora não será utilizado)*

## Classificação das Naturezas

O consultor deve exportar as naturezas da base do cliente e classificá-las com:

1. Código Agrupador nível 1 da DFC
2. Código Agrupador nível 2 da DFC
3. Ordenador do Demonstrativo *(por hora não será utilizado)*

## Construção das Views

Após os cadastros, o consultor deverá criar a view que faz a segmentação dos dados. Pode ser utilizado a tela exec, o botão de ação ou o banco de dados do cliente para realizar a criação.

- [VIEW_SQA_DFC_GERENCIAL](https://github.com/SQATEC/Demonstracao-FluxoCaixa/blob/main/Oracle/00%20-%20VIEW_SQA_DFC_GERENCIAL.sql)

## Considerações Finais

Todo o processo de construção do demonstrativo requer uma análise cuidadosa dos dados do cliente. Caso haja necessidade de alteração em alguma das etapas, é importante que um profissional qualificado seja consultado.

Por fim, vale ressaltar que o Demonstrativo de Fluxo de Caixa é uma ferramenta essencial para a tomada de decisões estratégicas. Portanto, garanta que todas as etapas de sua construção sejam realizadas com a devida atenção e cuidado.


## Construção do Dashboard

Para a construção do Dashboard na tela construtor de componentes de BI, poderá ser aproveitado o xml do link a seguir:

- Modelo Oracle: [component.xml](https://github.com/SQATEC/Demonstracao-FluxoCaixa/blob/main/Oracle/01%20-%20Dashboard.xml)
- Modelo SQL Server: Consulte o documento original para o link.

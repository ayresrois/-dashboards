
# [SQA] - CONCILIAÇÃO RECEITA E CMV

Passos para implementação do dashboard.

###  1.Criação Da Function SQA_OBTEMCUSTO
[Atualizar Função_SQA_OBTEMCUSTO.sql](https://github.com/SQATEC/Integracao-Contabil/blob/e6d42270db58ae502088330d91f277bd8e9e74f8/%5BSQA%5D%20-%20CONCILIA%C3%87%C3%83O%20RECEITA%20E%20CMV/Function_SQA_OBTEMCUSTO.sql)

###  2.Criação Da View AD_VW_RAZAO_ANALITICO
[AD_VW_RAZAO_ANALITICO.sql](https://github.com/SQATEC/Integracao-Contabil/blob/e6d42270db58ae502088330d91f277bd8e9e74f8/%5BSQA%5D%20-%20CONCILIA%C3%87%C3%83O%20RECEITA%20E%20CMV/_AD_VW_RAZAO_ANALITICO.sql)

###  3. Importação do componente
- Através da Rotina Construtor de Componentes BI, subir o componente a seguir.
	- [Componente Oracle.xml](https://github.com/SQATEC/Integracao-Contabil/blob/e6d42270db58ae502088330d91f277bd8e9e74f8/%5BSQA%5D%20-%20CONCILIA%C3%87%C3%83O%20RECEITA%20E%20CMV/CONCILIA%C3%87%C3%83O_RECEITA_E_CMV_ORACLE.xml)
	- [Componente SQLServer.xml](https://github.com/SQATEC/Integracao-Contabil/blob/e6d42270db58ae502088330d91f277bd8e9e74f8/%5BSQA%5D%20-%20CONCILIA%C3%87%C3%83O%20RECEITA%20E%20CMV/CONCILIA%C3%87%C3%83O_RECEITA_E_CMV_SQL.xml)
- Lembre-se de adicionar o componente implantado à um dashboard, e adicionar um lançador de tela.


    

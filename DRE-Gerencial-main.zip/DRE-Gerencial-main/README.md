# Documentação do Processo de Construção do Demonstrativo

## Cadastro de Campos Adicionais

### Tabela: TGFNAT (Natureza) (teste)

- Campo: **CODAGRUP**
    - Descrição: Agrupador Demonstrativo SQA
    - Tipo de dados: Número Inteiro
    - Apresentação: Lista de Opções
    - Função do Campo: Campo responsável por classificar e agrupar os grupos do demonstrativo
 
  **IMPORTANTE: Antes de seguir o próximo passo, é importante obter o NUCAMPO do campo adicional criado e preencher o campo E1 da planilha presente no próximo passo. Para isso, execute a consulta presente neste [link.](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/03%20-%20Consulta%20NUCAMPO.sql)**
  
  A planilha com a estrutura de inserção na lista de opções pode ser obtida [aqui.](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/04%20-%20PLANILHA%20TDDOPC.xlsx)



| Valor | Opção                      | Ordem |
|-------|----------------------------|-------|
| 100   | Receita de Vendas          | 10    |
| 200   | Devolução de Vendas        | 20    |
| 300   | Compra de Mercadorias      | 40    |
| 310   | Custos com Mão de Obra     | 50    |
| 320   | Custos Operacionais        | 60    |
| 330   | Custos com Materia Prima   | 65    |
| 340   | Custos CSP                 | 70    |
| 350   | Custos Indiretos Produção  | 75    |
| 400   | Devolução de Compras       | 45    |
| 510   | Despesas com Pessoal       | 80    |
| 520   | Despesas Comerciais        | 90    |
| 530   | Despesas Estruturais       | 100   |
| 540   | Despesas com Serviço       | 110   |
| 550   | Despesas com Logística     | 120   |
| 560   | Despesas com Marketing     | 130   |
| 570   | Despesas Gerais            | 140   |
| 600   | Socios/Diretoria           | 200   |
| 700   | Adiantamentos              | 210   |
| 800   | Imobilizado                | 220   |
| 900   | Endividamento              | 230   |
| 950   | Investimento               | 235   |
| 1000  | Operações de Estoque       | 190   |
| 1010  | Operações IntraGrupo       | 240   |
| 1100  | Despesas Financeiras       | 160   |
| 1200  | Receitas Financeiras       | 150   |
| 1300  | Receitas Não Operacionais  | 170   |
| 1350  | Despesas Não Operacionais  | 180   |
| 1400  | Guias Impostos             | 30    |
| 9999  | Impostos Sobre o Resultado | 250   |


- Campo: **COMPOEDRE**
    - Descrição do Campo: Compõe DRE SQA
    - Tipo de dados: Texto
    - Apresentação: CheckBox
    - Função do Campo: Campo responsável por identificar as naturezas que irão compor os demonstrativos

## Classificação das Naturezas

O consultor deve exportar ou abrir a tela de naturezas da base do cliente e classificá-las com:

1. Código Agrupador (CODAGRUP)
2. Se compõe ou não a DRE (COMPOEDRE)

## Construção da Function OBTEMCUSTO
A função OBTEMCUSTO nativa pode apresentar problemas quando há algum produto sem custo e/ou custo 0. Por conta disso, faz-se necessária a criação de uma estrutura para obtenção de custeio. Para acessar a estrutura siga este [link.](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/05%20-%20Function_SQA_OBTEMCUSTO.sql) 


## Construção das Views

Após as classificações e os cadastros, o consultor deverá criar as views que fazem a segmentação dos dados. Pode ser utilizado a tela exec, o botão de ação ou o banco de dados do cliente para realizar a criação.

- [VIEW_SQA_CONSULTA_CUSTOS_DRE](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/00%20-%20VIEW_SQA_CONSULTA_CUSTOS_DRE.sql)
- [VIEW_SQA_CONSULTA_FINANCEIRO_DRE](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/00%20-%20VIEW_SQA_CONSULTA_FINANCEIRO_DRE.sql)
- [VIEW_SQA_CONSULTA_PORTAL_DRE](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/00%20-%20VIEW_SQA_CONSULTA_PORTAL_DRE.sql)
- [VIEW_SQA_DRE_GERENCIAL](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/01%20-%20VIEW_SQA_DRE_GERENCIAL.sql)

## Construção da Tabela Adicional

Uma tabela adicional é utilizada para receber os dados das views. Isso é feito para não sobrecarregar o banco de dados do cliente. Para efetuar a criação, siga [este link](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/02%20-%20TABLE_AD_SQA_DRE_GERENCIAL.sql).

## Construção da Procedure e Ação Agendada

Para acessar a procedure, siga [este link](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/1%20-%20Objetos/06%20-%20PROCEDURE_STP_CARGA_SQA_DRE.SQL).

Deve-se criar uma ação agendada para rodar a procedure de atualização da tabela adicional. Sugerimos que essa ação seja agendada para rodar 3 vezes ao dia ou todos os dias às 21:00, ou conforme a necessidade do cliente. Para isso, siga os passos abaixo:

1. Acesse o menu principal do sistema.
2. Selecione a opção "Ações Agendadas".
3. Clique em "Novo" para criar uma nova ação.
4. Preencha os campos necessários:
- **Nome:** [SQA] Atualização da Tabela Adicional
- **Procedure:** STP_CARGA_SQA_DRE (ou o nome que você deu à sua procedure)
- **Horário de Execução:** De acordo com a necessidade do cliente. Sugerimos três vezes ao dia.
5. Salve as alterações.

## Construção do Dashboard

Para a construção do Dashboard na tela construtor de componentes de BI, poderá ser aproveitado o xml do link a seguir:

- Modelo Oracle: [component.xml](https://github.com/SQATEC/Demonstracao-Resultado/blob/main/2%20-%20query_Dashboard/04%20-%20component.xml)
- Modelo SQL Server: *Em desenvolvimento*

Além disso, é importante anexar o componete HTML5 para que os cards fiquem visíveis. Para isso, temos os links:

- Modelo Oracle: [cards.zip](https://github.com/SQATEC/DRE-Gerencial/blob/main/3%20-%20design_Cards/569_html5Component.zip)
- Modelo SQL Server: *Em desenvolvimento*

## Considerações Finais

Todo o processo de construção do demonstrativo requer uma análise cuidadosa dos dados do cliente. Caso haja necessidade de alteração em alguma das etapas, é importante que um profissional qualificado seja consultado. Além disso, lembre-se que a frequência de atualização dos dados deve estar de acordo com a rotina operacional do cliente, de modo a garantir a exibição de informações sempre atualizadas e relevantes.

Por fim, vale ressaltar que o Demonstrativo de Resultado é uma ferramenta essencial para a tomada de decisões estratégicas. Portanto, garanta que todas as etapas de sua construção sejam realizadas com a devida atenção e cuidado.

/* ---------------------------------------------- ATENÇÃO ----------------------------------------------
   O RESULTADO OBTIDO NESTA CONSULTA DEVE SUBSTITUIR O CAMPO E1 DA PLANILHA DE INSERÇÃO DE OPÇÕES DO CAMPO.
   ------------------------------------------------------------------------------------------------------- */
SELECT NUCAMPO 
FROM TDDCAM
WHERE NOMETAB = 'TGFNAT'
    AND NOMECAMPO = 'AD_CODAGRUP'

